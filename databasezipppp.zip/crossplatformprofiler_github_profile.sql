-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: crossplatformprofiler
-- ------------------------------------------------------
-- Server version	8.0.46

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `github_profile`
--

DROP TABLE IF EXISTS `github_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `github_profile` (
  `GitHub_ID` int NOT NULL AUTO_INCREMENT,
  `Developer_ID` int NOT NULL,
  `GitHub_Username` varchar(100) NOT NULL,
  `GitHub_URL` varchar(255) NOT NULL,
  `Bio` text,
  `Company` varchar(100) DEFAULT NULL,
  `Location` varchar(100) DEFAULT NULL,
  `Followers` int DEFAULT '0',
  `Following` int DEFAULT '0',
  `Public_Repos` int DEFAULT '0',
  `Public_Gists` int DEFAULT '0',
  `Account_Created` date DEFAULT NULL,
  PRIMARY KEY (`GitHub_ID`),
  UNIQUE KEY `Developer_ID` (`Developer_ID`),
  CONSTRAINT `FK_Developer_GitHub` FOREIGN KEY (`Developer_ID`) REFERENCES `developer` (`Developer_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `github_profile_ibfk_1` FOREIGN KEY (`Developer_ID`) REFERENCES `developer` (`Developer_ID`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-29  1:26:41
